# SPDX-FileCopyrightText: Copyright (c) 2021 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its
# contributors may be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# Copyright (c) 2021 ETH Zurich, Nikita Rudin

import torch
import torch.nn as nn
import torch.optim as optim

from .mlp_encoder import MLP_Encoder
from .actor_critic import ActorCritic
from .rollout_storage import RolloutStorage


class PPO:
    actor_critic: ActorCritic
    encoder: MLP_Encoder

    def __init__(
        self,
        num_group,
        encoder,
        actor_critic,
        num_learning_epochs=1,
        num_mini_batches=1,
        clip_param=0.2,
        gamma=0.998,
        lam=0.95,
        value_loss_coef=1.0,
        entropy_coef=0.0,
        learning_rate=1e-3,
        max_grad_norm=1.0,
        use_clipped_value_loss=True,
        schedule="fixed",
        desired_kl=0.01,
        vae_beta=1.0,
        est_learning_rate=1.0e-3,
        ts_learning_rate=1.0e-4,
        critic_take_latent=False,
        early_stop=False,
        anneal_lr=False,
        device="cpu",
    ):
        self.device = device
        self.num_group = num_group

        self.desired_kl = desired_kl
        self.early_stop = early_stop
        self.schedule = schedule
        self.learning_rate = learning_rate
        self.anneal_lr = anneal_lr
        self.vae_beta = vae_beta
        self.critic_take_latent = critic_take_latent

        self.encoder = encoder

        # PPO components
        self.actor_critic = actor_critic
        self.actor_critic.to(self.device)
        self.storage = None  # initialized later
        self.optimizer = optim.Adam([{"params": self.actor_critic.parameters()}], lr=learning_rate)

        if self.encoder.num_output_dim != 0:
            self.extra_optimizer = optim.Adam(
                self.encoder.parameters(), lr=est_learning_rate
            )
        else:
            self.extra_optimizer = None
        self.transition = RolloutStorage.Transition()

        # PPO parameters
        self.clip_param = clip_param
        self.num_learning_epochs = num_learning_epochs
        self.num_mini_batches = num_mini_batches
        self.value_loss_coef = value_loss_coef
        self.entropy_coef = entropy_coef
        self.gamma = gamma
        self.lam = lam
        self.max_grad_norm = max_grad_norm
        self.use_clipped_value_loss = use_clipped_value_loss

    def init_storage(
        self,
        num_envs,
        num_transitions_per_env,
        actor_obs_shape,
        critic_obs_shape,
        obs_history_shape,
        commands_shape,
        action_shape,
    ):
        self.storage = RolloutStorage(
            num_envs,
            num_transitions_per_env,
            actor_obs_shape,
            critic_obs_shape,
            obs_history_shape,
            commands_shape,
            action_shape,
            self.device,
        )

    def test_mode(self):
        self.actor_critic.test()

    def train_mode(self):
        self.actor_critic.train()


    def act(self, obs, obs_history, commands, critic_obs):
        # critic_obs_full = [critic_raw, commands]
        critic_obs_full = torch.cat((critic_obs, commands), dim=-1)

        # actor input = [encoder_out, obs, commands]
        encoder_out = self.encoder.encode(obs_history)
        actor_in = torch.cat((encoder_out, obs, commands), dim=-1)

        # sample action from current policy (stochastic)
        raw_actions = self.actor_critic.act(actor_in)

        # ✅ clip action here and store the clipped version
        clip = getattr(self, "clip_actions", None)
        if clip is not None:
            actions = torch.clamp(raw_actions, -clip, clip)
        else:
            actions = raw_actions
        if not hasattr(self, "_dbg_clip"):
            self._dbg_clip = {"n":0, "clip":0}
        self._dbg_clip["n"] += actions.numel()
        self._dbg_clip["clip"] += (raw_actions != actions).sum().item()
        self.transition.actions = actions.detach()

        # ✅ critic value (MUST be set, otherwise time_out bootstrap crashes)
        if self.critic_take_latent:
            critic_in = torch.cat((critic_obs_full, encoder_out), dim=-1)
        else:
            critic_in = critic_obs_full
        self.transition.values = self.actor_critic.evaluate(critic_in).detach()

        # log prob of the *same* action stored/executed
        self.transition.actions_log_prob = self.actor_critic.get_actions_log_prob(actions).detach()
        self.transition.action_mean = self.actor_critic.action_mean.detach()
        self.transition.action_sigma = self.actor_critic.action_std.detach()

        # record obs
        self.transition.observations = obs
        self.transition.critic_obs = critic_obs_full  # 注意这里按你 storage 期望存 full critic_obs
        self.transition.observation_history = obs_history
        self.transition.commands = commands

        return self.transition.actions




    def process_env_step(self, rewards, dones, infos, next_obs=None):
        self.transition.rewards = rewards.clone()
        self.transition.dones = dones
        # Bootstrapping on time outs
        # if "time_outs" in infos:
        #     self.transition.rewards += self.gamma * torch.squeeze(
        #         self.transition.values
        #         * infos["time_outs"].unsqueeze(1).to(self.device),
        #         1,
        #     )
        if "time_outs" in infos:
            self.transition.rewards += self.gamma * (
                self.transition.values * infos["time_outs"].unsqueeze(1).to(self.device)
            )

        # Record the transition
        self.transition.next_observations = next_obs
        self.storage.add_transitions(self.transition)
        self.transition.clear()
        self.actor_critic.reset(dones)

    def compute_returns(self, last_critic_obs):
        last_values = self.actor_critic.evaluate(last_critic_obs).detach()
        self.storage.compute_returns(last_values, self.gamma, self.lam)

    def update(self):
        num_updates = 0
        mean_value_loss = 0
        mean_surrogate_loss = 0
        mean_kl = 0
        generator = self.storage.mini_batch_generator(
            self.storage.num_envs,
            self.num_mini_batches,
            self.num_learning_epochs,
        )
        for (
            obs_batch,
            critic_obs_batch,
            obs_history_batch, _,
            group_commands_batch,
            actions_batch,
            target_values_batch,
            advantages_batch,
            returns_batch,
            old_actions_log_prob_batch,
            old_mu_batch,
            old_sigma_batch,
        ) in generator:
            encoder_out_batch = self.encoder.encode(obs_history_batch)
            commands_batch = group_commands_batch
            actor_input = torch.cat(
                (encoder_out_batch, obs_batch, commands_batch),
                dim=-1,
            )
            self.actor_critic.act(actor_input)

            actions_log_prob_batch = self.actor_critic.get_actions_log_prob(
                actions_batch
            )

            value_batch = self.actor_critic.evaluate(critic_obs_batch)
            mu_batch = self.actor_critic.action_mean
            sigma_batch = self.actor_critic.action_std
            entropy_batch = self.actor_critic.entropy
            kl_mean = torch.tensor(0, device=self.device, requires_grad=False)
            with torch.inference_mode():
                kl = torch.sum(
                    torch.log(sigma_batch / old_sigma_batch + 1.0e-5)
                    + (
                        torch.square(old_sigma_batch)
                        + torch.square(old_mu_batch - mu_batch)
                    )
                    / (2.0 * torch.square(sigma_batch))
                    - 0.5,
                    axis=-1,
                )
                kl_mean = torch.mean(kl)
            # DEBUG ——start——
            with torch.inference_mode():
                sigma_min = sigma_batch.min().item()
                sigma_max = sigma_batch.max().item()
                mu_absmax = mu_batch.abs().max().item()

                # ratio 也算一下（你后面本来就要算 surrogate）
                log_ratio = actions_log_prob_batch - torch.squeeze(old_actions_log_prob_batch)
                log_ratio_absmax = log_ratio.abs().max().item()

                if kl_mean.item() > 0.2:   # 阈值你可以调，比如 0.1/0.5
                    print(f"[KL_SPIKE] kl={kl_mean.item():.4f} "
                        f"sigma_min={sigma_min:.2e} sigma_max={sigma_max:.2e} "
                        f"mu_absmax={mu_absmax:.2e} log_ratio_absmax={log_ratio_absmax:.2e}")
            # DEBUG ——end——
            # KL
            if self.desired_kl != None and self.schedule == "adaptive":
                with torch.inference_mode():
                    if kl_mean > self.desired_kl * 2.0:
                        self.learning_rate = max(1e-5, self.learning_rate / 1.5)
                    elif kl_mean < self.desired_kl / 2.0 and kl_mean > 0.0:
                        self.learning_rate = min(1e-2, self.learning_rate * 1.5)

                    for param_group in self.optimizer.param_groups:
                        param_group["lr"] = self.learning_rate

            # Surrogate loss
            # [FIX] 根本修复 NaN：clamp log_ratio 防止 torch.exp 溢出
            # 原代码直接 exp(new_log_prob - old_log_prob)，当新旧策略差异大时
            # 差值 > 88 → exp = Inf → loss = Inf → backward 产生 NaN 梯度
            # → actor 权重变 NaN → 永久崩溃。
            # clamp 到 [-20, 20] 后 ratio ∈ [2e-9, 5e8]，足够 PPO clip 工作，
            # 同时保证数值安全。
            log_ratio = actions_log_prob_batch - torch.squeeze(old_actions_log_prob_batch)
            log_ratio = torch.clamp(log_ratio, min=-20.0, max=20.0)
            ratio = torch.exp(log_ratio)
            advantages_batch = (advantages_batch - advantages_batch.mean()) / (advantages_batch.std() + 1e-8)
            surrogate = -torch.squeeze(advantages_batch) * ratio
            surrogate_clipped = -torch.squeeze(advantages_batch) * torch.clamp(
                ratio, 1.0 - self.clip_param, 1.0 + self.clip_param
            )
            surrogate_loss = torch.max(surrogate, surrogate_clipped).mean()

            # Value function loss
            if self.use_clipped_value_loss:
                value_clipped = target_values_batch + (
                    value_batch - target_values_batch
                ).clamp(-self.clip_param, self.clip_param)
                value_losses = (value_batch - returns_batch).pow(2)
                value_losses_clipped = (value_clipped - returns_batch).pow(2)
                value_loss = torch.max(value_losses, value_losses_clipped).mean()
            else:
                value_loss = (returns_batch - value_batch).pow(2).mean()

            entropy_batch_mean = entropy_batch.mean()
            loss = (
                surrogate_loss
                + self.value_loss_coef * value_loss
                - self.entropy_coef * entropy_batch_mean
            )

            if self.anneal_lr:
                frac = 1.0 - num_updates / (
                    self.num_learning_epochs * self.num_mini_batches
                )
                self.optimizer.param_groups[0]["lr"] = frac * self.learning_rate

            # Gradient step
            self.optimizer.zero_grad()
            if self.extra_optimizer is not None:
                self.extra_optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.actor_critic.parameters(), self.max_grad_norm)
            self.optimizer.step()

            num_updates += 1
            mean_value_loss += value_loss.item()
            mean_surrogate_loss += surrogate_loss.item()
            mean_kl += kl_mean.item()

            # [FIX] early_stop 移到 optimizer.step 之后：
            # 1. 保证每个 iteration 至少做 1 次梯度更新（不会 num_updates=0）
            # 2. 阈值用 desired_kl * 4（而非 * 1.5）避免过于敏感
            if self.desired_kl is not None and self.early_stop:
                if kl_mean > self.desired_kl * 4.0:
                    break

        num_updates_extra = 0
        mean_extra_loss = 0
        if self.extra_optimizer is not None:
            generator = self.storage.encoder_mini_batch_generator(
                self.num_mini_batches, self.num_learning_epochs
            )
            for (
                next_obs_batch,
                critic_obs_batch,
                obs_history_batch,
            ) in generator:
                if self.encoder.is_mlp_encoder:
                    self.encoder.encode(obs_history_batch)
                    encode_batch = self.encoder.get_encoder_out()

                if self.encoder.is_mlp_encoder:
                    enc_dim = encode_batch.shape[-1]
                    target_dim = min(enc_dim, critic_obs_batch.shape[-1])
                    extra_loss = (
                        (encode_batch[:, :target_dim] - critic_obs_batch[:, :target_dim]).pow(2).mean()
                    )
                else:
                    extra_loss = torch.zeros(1, device=self.device)

                self.extra_optimizer.zero_grad()
                extra_loss.backward()
                # encoder 也做梯度裁剪，防御性编程
                nn.utils.clip_grad_norm_(self.encoder.parameters(), self.max_grad_norm)
                self.extra_optimizer.step()

                num_updates_extra += 1
                mean_extra_loss += extra_loss.item()

        mean_value_loss /= max(1, num_updates)
        if num_updates_extra > 0:
            mean_extra_loss /= num_updates_extra
        mean_surrogate_loss /= max(1, num_updates)
        mean_kl /= max(1, num_updates)
        self.storage.clear()

        if hasattr(self, "_dbg_clip") and self._dbg_clip["n"] > 0:
            clip_rate = self._dbg_clip["clip"] / self._dbg_clip["n"]
            # 你可以每次都 print，或者每 N 次 print
            print(f"[DBG] action_clip_rate={clip_rate:.3f}")
            self._dbg_clip = {"n":0, "clip":0}

        return (mean_value_loss, mean_extra_loss, mean_surrogate_loss, mean_kl)