import collections
import logging
from typing import Any, Tuple, List

import numpy as np
import torch

from d2c.evaluators.sim.benchmark import BMEval


class IsaacGymEval(BMEval):
    """LeggedGym-style rollout evaluation.

    Key points:
      - Deterministic action for eval (use mean action if possible)
      - Correct terminated/truncated handling for IsaacGym VecEnv style:
          done + info["time_outs"] -> terminated/truncated
      - Episode stats collected per-environment like LeggedGym rollout:
          accumulate return/length; on done -> push to buffers; reset only done envs
      - DO NOT clamp action to [-1, 1] here (env already clips with cfg.normalization.clip_actions)
    """

    @staticmethod
    def _to_torch(x: Any, device: torch.device) -> torch.Tensor:
        if torch.is_tensor(x):
            return x.to(device=device)
        return torch.as_tensor(x, device=device)

    @staticmethod
    def _get_eval_action(policy: Any, obs: torch.Tensor) -> torch.Tensor:
        """Try to get deterministic (mean) action for Gaussian policies."""
        # leggedgym style
        if hasattr(policy, "act_inference"):
            return policy.act_inference(obs)

        # D2C ActorNetwork in ppo_nets_utils.py exposes actor_mean / actor_logstd
        if hasattr(policy, "actor_mean"):
            return policy.actor_mean(obs)

        # if policy keeps a distribution object (leggedgym ActorCritic uses self.distribution)
        if hasattr(policy, "distribution") and getattr(policy, "distribution") is not None:
            dist = getattr(policy, "distribution")
            if hasattr(dist, "mean"):
                return dist.mean

        # fallback: call policy forward
        out = policy(obs)
        if isinstance(out, (tuple, list)):
            out = out[0]
        return out

    def _eval_policy_episodes(self, policy: Any) -> Tuple[float, float, np.ndarray]:
        # ---- config ----
        target_eps = int(getattr(self, "_n_episodes", 10))
        max_steps = int(getattr(self, "_n_episodes_max_step", 5000))

        dbg_on = (int(getattr(self, "_debug", 0)) == 1)  # you can set evaluator._debug = 1
        dbg_every = int(getattr(self, "_debug_every", 200))

        # ---- device ----
        env_device = getattr(self._env, "device", None)
        if env_device is None:
            env_device = getattr(self._agent, "_device", "cpu")
        env_device = torch.device(env_device)

        # ---- policy mode ----
        was_training = getattr(policy, "training", False)
        if hasattr(policy, "eval"):
            policy.eval()

        # ---- reset ----
        obs = self._env.reset()
        if isinstance(obs, tuple) and len(obs) == 2:
            obs = obs[0]
        obs_t = self._to_torch(obs, env_device).to(torch.float32)

        # infer num_envs
        num_envs = int(obs_t.shape[0]) if obs_t.ndim >= 2 else 1

        # ---- rollout buffers (per-env) ----
        ep_ret = torch.zeros((num_envs,), device=env_device, dtype=torch.float32)
        ep_len = torch.zeros((num_envs,), device=env_device, dtype=torch.int64)

        ep_returns: List[float] = []
        ep_lengths: List[int] = []

        # optional moving buffers like LeggedGym logger (not required, but handy)
        rewbuffer = collections.deque(maxlen=max(100, target_eps))
        lenbuffer = collections.deque(maxlen=max(100, target_eps))

        # ---- rollout ----
        for step_i in range(max_steps):
            with torch.no_grad():
                act_t = self._get_eval_action(policy, obs_t)

            # ensure shape for single env
            if num_envs == 1 and act_t.ndim == 1:
                act_t = act_t.unsqueeze(0)

            # IMPORTANT: don't clamp here; env clips itself with cfg.normalization.clip_actions
            step_out = self._env.step(act_t)

            # parse step output
            if isinstance(step_out, tuple) and len(step_out) == 4:
                next_obs, reward, done, info = step_out
                info = info if isinstance(info, dict) else {}

                reward_t = self._to_torch(reward, env_device).to(torch.float32).view(-1)
                done_t = self._to_torch(done, env_device).to(torch.bool).view(-1)

                time_outs = info.get("time_outs", None)
                if time_outs is not None:
                    truncated_t = self._to_torch(time_outs, env_device).to(torch.bool).view(-1)
                else:
                    truncated_t = torch.zeros_like(done_t, dtype=torch.bool)

                terminated_t = done_t & (~truncated_t)

            elif isinstance(step_out, tuple) and len(step_out) == 5:
                next_obs, reward, terminated, truncated, info = step_out
                info = info if isinstance(info, dict) else {}

                reward_t = self._to_torch(reward, env_device).to(torch.float32).view(-1)
                terminated_t = self._to_torch(terminated, env_device).to(torch.bool).view(-1)
                truncated_t = self._to_torch(truncated, env_device).to(torch.bool).view(-1)

            else:
                raise RuntimeError(
                    f"Unexpected env.step return format: type={type(step_out)} "
                    f"len={len(step_out) if isinstance(step_out,(tuple,list)) else 'NA'}"
                )

            next_obs_t = self._to_torch(next_obs[0] if isinstance(next_obs, tuple) and len(next_obs) == 2 else next_obs, env_device).to(torch.float32)

            done_eval = terminated_t | truncated_t

            # accumulate
            ep_ret += reward_t
            ep_len += 1

            # debug (low frequency)
            if dbg_on and (step_i % dbg_every == 0):
                done_ratio = float(done_eval.float().mean().item()) if num_envs > 1 else float(done_eval.item())
                term_ratio = float(terminated_t.float().mean().item()) if num_envs > 1 else float(terminated_t.item())
                trunc_ratio = float(truncated_t.float().mean().item()) if num_envs > 1 else float(truncated_t.item())
                logging.info(
                    f"[EVAL DBG] step={step_i} done_ids.size={int(done_eval.sum().item())} "
                    f"terminated.true_ratio={term_ratio:.6f} truncated.true_ratio={trunc_ratio:.6f} "
                    f"done.true_ratio={done_ratio:.6f} collected_eps={len(ep_returns)}/{target_eps}"
                )

            # finalize episodes for done envs
            if done_eval.any():
                done_ids = torch.nonzero(done_eval, as_tuple=False).view(-1)

                # gather stats
                for idx in done_ids.tolist():
                    r = float(ep_ret[idx].item())
                    l = int(ep_len[idx].item())
                    ep_returns.append(r)
                    ep_lengths.append(l)
                    rewbuffer.append(r)
                    lenbuffer.append(l)
                    ep_ret[idx] = 0.0
                    ep_len[idx] = 0

                # reset only done envs if supported
                if hasattr(self._env, "reset_idx"):
                    obs_reset = self._env.reset_idx(done_ids.to(device=env_device, dtype=torch.int64))
                    if isinstance(obs_reset, tuple) and len(obs_reset) == 2:
                        obs_reset = obs_reset[0]
                    obs_t = self._to_torch(obs_reset, env_device).to(torch.float32)
                else:
                    # fallback: full reset (rare)
                    obs = self._env.reset()
                    if isinstance(obs, tuple) and len(obs) == 2:
                        obs = obs[0]
                    obs_t = self._to_torch(obs, env_device).to(torch.float32)
            else:
                obs_t = next_obs_t

            if len(ep_returns) >= target_eps:
                break

        # restore policy mode
        if hasattr(policy, "train"):
            policy.train(was_training)

        if len(ep_returns) == 0:
            results_arr = np.array([0.0], dtype=np.float64)
            lengths_arr = np.array([0.0], dtype=np.float64)
        else:
            results_arr = np.array(ep_returns[:target_eps], dtype=np.float64)
            lengths_arr = np.array(ep_lengths[:target_eps], dtype=np.float64)

        mean_ep_return = float(np.mean(results_arr))
        std_ep_return = float(np.std(results_arr))
        mean_ep_len = float(np.mean(lengths_arr)) if lengths_arr.size else 0.0
        mean_step_reward = float(np.mean(results_arr / np.maximum(lengths_arr, 1.0))) if lengths_arr.size else 0.0

        logging.info("=" * 20 + f" Complete evaluation of {results_arr.shape[0]} episodes! " + "=" * 20)
        logging.info(f"Mean episode return: {mean_ep_return:.6f}")
        logging.info(f"Mean episode length: {mean_ep_len:.2f}")
        logging.info(f"Mean step reward:    {mean_step_reward:.6f}")

        return mean_ep_return, std_ep_return, results_arr
