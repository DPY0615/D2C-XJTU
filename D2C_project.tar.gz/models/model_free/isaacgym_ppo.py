"""
Implementation of PPO (Proximal Policy Optimization)
Paper: https://arxiv.org/abs/1707.06347
"""

import collections
import copy
from typing import Any, Dict, Tuple, Optional

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn, Tensor
import os

from d2c.models.base import BaseAgent, BaseAgentModule
from d2c.utils import utils, onpolicytransitions
from d2c.networks_and_utils_for_agent.ppo_nets_utils import ActorNetwork, CriticNetwork


class ISAACGYM_PPOAgent(BaseAgent):
    """
    PPO Agent for online reinforcement learning.
    Compatible with:
      - IsaacGym/LeggedGym VecEnv style: step -> (obs, rew, done, info)
      - Gymnasium style: step -> (obs, rew, terminated, truncated, info)
    """

    def __init__(
        self,
        rollout_sim_freq: int = 1000,
        rollout_sim_num: int = 1000,
        max_traj_length: int = 1000,
        env_seed: int = 42,
        total_timesteps: int = 1_000_000,
        num_envs: int = 1,
        num_steps: int = 2048,
        anneal_lr: bool = True,
        gae_lambda: float = 0.95,
        num_minibatches: int = 32,
        update_epochs: int = 10,
        norm_adv: bool = True,
        clip_coef: float = 0.2,
        clip_vloss: bool = True,
        ent_coef: float = 0.0,
        vf_coef: float = 0.5,
        max_grad_norm: float = 0.5,
        target_kl: Optional[float] = None,
        batch_size: int = 0,
        mini_batch_size: int = 0,
        num_iterations: int = 0,
        **kwargs: Any,
    ) -> None:
        self._rollout_sim_freq = rollout_sim_freq
        self._rollout_sim_num = rollout_sim_num
        self._max_traj_length = max_traj_length
        self._p_info = collections.OrderedDict()

        self._total_timesteps = total_timesteps
        self._num_envs = num_envs
        self._num_steps = num_steps
        self._anneal_lr = anneal_lr
        self._gae_lambda = gae_lambda
        self._num_minibatches = num_minibatches
        self._update_epochs = update_epochs
        self._norm_adv = norm_adv
        self._clip_coef = clip_coef
        self._clip_vloss = clip_vloss
        self._ent_coef = ent_coef
        self._vf_coef = vf_coef
        self._max_grad_norm = max_grad_norm
        self._target_kl = target_kl

        self._batch_size = batch_size
        self._mini_batch_size = mini_batch_size
        self._num_iterations = num_iterations
        self._env_seed = env_seed

        super().__init__(**kwargs)

    def _get_modules(self) -> utils.Flags:
        model_params_q, n_q_fns = self._model_params.q
        model_params_p = self._model_params.p[0]

        def q_net_factory():
            return CriticNetwork(
                observation_space=self._observation_space,
                action_space=self._action_space,
                fc_layer_params=model_params_q,
                device=self._device,
            )

        def p_net_factory():
            return ActorNetwork(
                observation_space=self._observation_space,
                action_space=self._action_space,
                fc_layer_params=model_params_p,
                device=self._device,
            )

        return utils.Flags(
            p_net_factory=p_net_factory,
            q_net_factory=q_net_factory,
            n_q_fns=n_q_fns,
            device=self._device,
        )

    def _build_fns(self) -> None:
        self._agent_module = AgentModule(modules=self._modules)
        self._q_fns = self._agent_module.q_nets
        self._q_target_fns = self._agent_module.q_target_nets
        self._p_fn = self._agent_module.p_net
        self._p_target_fn = self._agent_module.p_target_net

    def _infer_spaces(self):
        if hasattr(self._env, "observation_space") and self._env.observation_space is not None:
            obs_space = self._env.observation_space
        elif hasattr(self._env, "_env") and hasattr(self._env._env, "single_observation_space"):
            obs_space = self._env._env.single_observation_space
        else:
            raise AttributeError("Cannot infer observation_space from env.")

        if hasattr(self._env, "action_space") and self._env.action_space is not None:
            act_space = self._env.action_space
        elif hasattr(self._env, "_env") and hasattr(self._env._env, "single_action_space"):
            act_space = self._env._env.single_action_space
        else:
            raise AttributeError("Cannot infer action_space from env.")

        return obs_space, act_space

    def _init_vars(self) -> None:
        self._batch_size = int(self._num_envs * self._num_steps)
        self._mini_batch_size = int(self._batch_size // self._num_minibatches)

        self._observation_space, self._action_space = self._infer_spaces()

        self._train_data = onpolicytransitions.OnPolicyTransitions(
            num_steps=self._num_steps,
            num_envs=self._num_envs,
            obs_shape=self._observation_space.shape,
            action_shape=self._action_space.shape,
            device=self._device,
        )

        self._current_iteration = 0
        self._total_iterations = 0
        self._next_obs = None
        self._next_dones = None
        self._episode_rewards = 0.0

    def _build_optimizers(self) -> None:
        opts = self._optimizers
        self._optimizer = utils.get_optimizer(opts.ac[0])(
            parameters=list(self._p_fn.parameters()) + list(self._q_fns[0].parameters()),
            lr=opts.ac[1],
            weight_decay=self._weight_decays,
        )
        if len(opts.ac) >= 3:
            self._optimizer.param_groups[0]["eps"] = opts.ac[2]

    def _env_reset(self, seed: Optional[int] = None):
        out = self._env.reset(seed=seed) if seed is not None else self._env.reset()
        if isinstance(out, tuple) and len(out) == 2:
            obs, _info = out
            return obs
        return out

    def _env_step(self, action: torch.Tensor):
        out = self._env.step(action)

        dbg_on = (os.getenv("D2C_PPO_DEBUG", "0") == "1")
        dbg_every = int(os.getenv("D2C_PPO_DEBUG_EVERY", "200"))
        if not hasattr(self, "_dbg_envstep_i"):
            self._dbg_envstep_i = 0
        self._dbg_envstep_i += 1

        def _stat_tensor(x, name):
            if not torch.is_tensor(x):
                x = torch.as_tensor(x)
            xd = x.detach()
            if xd.dtype == torch.bool:
                true_cnt = int(xd.sum().item())
                ratio = true_cnt / max(1, xd.numel())
                print(f"  {name}: bool true_cnt={true_cnt} true_ratio={ratio:.6f} shape={tuple(xd.shape)}")
            else:
                xf = xd.float()
                print(f"  {name}: min={float(xf.min()):.6g} max={float(xf.max()):.6g} mean={float(xf.mean()):.6g} std={float(xf.std(unbiased=False)):.6g} shape={tuple(xd.shape)}")

        # -------- 4-return: (obs, rew, done, info) --------
        if isinstance(out, tuple) and len(out) == 4:
            obs, rew, done, info = out

            obs = obs if torch.is_tensor(obs) else torch.as_tensor(obs, device=self._device, dtype=torch.float32)
            rew = rew if torch.is_tensor(rew) else torch.as_tensor(rew, device=self._device, dtype=torch.float32)

            done = done if torch.is_tensor(done) else torch.as_tensor(done, device=self._device)
            done = done.to(dtype=torch.bool)

            info = dict(info) if isinstance(info, dict) else {}

            # time_outs -> truncated
            if "time_outs" in info and info["time_outs"] is not None:
                time_outs = info["time_outs"]
                time_outs = time_outs if torch.is_tensor(time_outs) else torch.as_tensor(time_outs, device=self._device)
                truncated = time_outs.to(dtype=torch.bool)
            else:
                truncated = torch.zeros_like(done, dtype=torch.bool)

            terminated = done & (~truncated)

            if dbg_on and (self._dbg_envstep_i % dbg_every == 0):
                print(f"\n[PPO DBG] _env_step i={self._dbg_envstep_i}")
                _stat_tensor(rew, "reward")
                _stat_tensor(terminated, "terminated")
                _stat_tensor(truncated, "truncated")
                if "time_outs" in info and info["time_outs"] is not None:
                    _stat_tensor(info["time_outs"], "info.time_outs")

            return obs, rew, terminated, truncated, info

        # -------- 5-return: gymnasium style --------
        if isinstance(out, tuple) and len(out) == 5:
            obs, rew, terminated, truncated, info = out

            obs = obs if torch.is_tensor(obs) else torch.as_tensor(obs, device=self._device, dtype=torch.float32)
            rew = rew if torch.is_tensor(rew) else torch.as_tensor(rew, device=self._device, dtype=torch.float32)

            terminated = terminated if torch.is_tensor(terminated) else torch.as_tensor(terminated, device=self._device)
            truncated  = truncated  if torch.is_tensor(truncated)  else torch.as_tensor(truncated,  device=self._device)
            terminated = terminated.to(dtype=torch.bool)
            truncated  = truncated.to(dtype=torch.bool)

            info = dict(info) if isinstance(info, dict) else {}

            if dbg_on and (self._dbg_envstep_i % dbg_every == 0):
                print(f"\n[PPO DBG] _env_step i={self._dbg_envstep_i} (5-return)")
                _stat_tensor(rew, "reward")
                _stat_tensor(terminated, "terminated")
                _stat_tensor(truncated, "truncated")

            return obs, rew, terminated, truncated, info

        raise ValueError(f"Unsupported env.step() return format: len={len(out) if isinstance(out, tuple) else 'NA'}")

    def _build_q_loss(self, batch: Dict, mb_inds: np.ndarray) -> Tuple[Tensor, Dict]:
        b_obs = batch["s1"]
        b_returns = batch["return"]
        b_values = batch["value"]

        newvalue = self._q_fns[0](b_obs[mb_inds]).view(-1)
        if self._clip_vloss:
            v_loss_unclipped = (newvalue - b_returns[mb_inds]) ** 2
            v_clipped = b_values[mb_inds] + torch.clamp(
                newvalue - b_values[mb_inds],
                -self._clip_coef,
                self._clip_coef,
            )
            v_loss_clipped = (v_clipped - b_returns[mb_inds]) ** 2
            v_loss = 0.5 * torch.max(v_loss_unclipped, v_loss_clipped).mean()
        else:
            v_loss = 0.5 * ((newvalue - b_returns[mb_inds]) ** 2).mean()

        info = collections.OrderedDict(v_loss=v_loss.detach().mean())
        return v_loss, info

    def _build_p_loss(self, batch: Dict, mb_inds: np.ndarray) -> Tuple[Tensor, Tensor, Tensor, Dict]:
        b_obs = batch["s1"]
        b_logprobs = batch["logprob"]
        b_actions = batch["a1"]
        b_advantages = batch["advantage"]

        _, newlogprobs, entropy = self._p_fn(b_obs[mb_inds], b_actions[mb_inds])
        logratio = newlogprobs - b_logprobs[mb_inds]
        ratio = logratio.exp()

        old_approx_kl, approx_kl, _clipfracs = self.calculate_kl(logratio)

        mb_adv = b_advantages[mb_inds]
        if self._norm_adv:
            mb_adv = (mb_adv - mb_adv.mean()) / (mb_adv.std() + 1e-8)

        pg_loss1 = -mb_adv * ratio
        pg_loss2 = -mb_adv * torch.clamp(ratio, 1 - self._clip_coef, 1 + self._clip_coef)
        pg_loss = torch.max(pg_loss1, pg_loss2).mean()
        entropy_loss = entropy.mean()

        info = collections.OrderedDict(
            actor_loss=pg_loss.detach().mean(),
            log_pi=newlogprobs.detach().mean(),
            actor_entropy=entropy_loss.detach().mean(),
            approx_kl=approx_kl.detach().mean(),
            old_approx_kl=old_approx_kl.detach().mean(),
        )
        # return pg_loss, entropy_loss, old_approx_kl, info
        return pg_loss, entropy_loss, approx_kl, info


    def train_step(self) -> None:
        train_batch = self._get_train_batch()
        info = self._optimize_step(train_batch)
        for k, v in info.items():
            self._train_info[k] = v.item() if torch.is_tensor(v) else float(v)

    def _get_train_batch(self) -> Dict:
        with torch.no_grad():
            if self._anneal_lr:
                frac = 1.0 - (self._current_iteration - 1.0) / max(1.0, float(self._total_iterations))
                lrnow = frac * self._optimizers.ac[1]
                self._optimizer.param_groups[0]["lr"] = lrnow

            for step in range(self._num_steps):
                self._global_step += self._num_envs

                state = self._next_obs
                self._train_data.obs[step] = state
                self._train_data.dones[step] = self._next_dones

                action, logprob, _ = self._p_fn(state)

                value = self._q_fns[0](state)

                self._train_data.values[step] = value.flatten()
                self._train_data.actions[step] = action
                self._train_data.logprobs[step] = logprob

                next_state, reward, terminated, truncated, infos = self._env_step(action)
                terminated_t = terminated if torch.is_tensor(terminated) else torch.as_tensor(terminated, device=self._device)
                truncated_t = truncated if torch.is_tensor(truncated) else torch.as_tensor(truncated, device=self._device)

                done_for_gae = terminated_t.bool()
                self._next_dones = done_for_gae.to(self._device, dtype=torch.float32)
                self._next_obs = torch.as_tensor(next_state, device=self._device, dtype=torch.float32)
                self._train_data.rewards[step] = torch.as_tensor(reward, device=self._device, dtype=torch.float32)

        return self._train_data.get_batch()

    def _optimize_step(self, batch: Dict) -> Dict:
        b_batch = self.get_training_batch(batch)
        b_inds = np.arange(self._batch_size)

        for _epoch in range(self._update_epochs):
            np.random.shuffle(b_inds)
            for start in range(0, self._batch_size, self._mini_batch_size):
                end = start + self._mini_batch_size
                mb_inds = b_inds[start:end]

                pg_loss, entropy_loss, old_approx_kl, p_info = self._build_p_loss(b_batch, mb_inds)
                v_loss, q_info = self._build_q_loss(b_batch, mb_inds)
                loss = pg_loss - self._ent_coef * entropy_loss + self._vf_coef * v_loss

                self._optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(
                    list(self._p_fn.parameters()) + list(self._q_fns[0].parameters()),
                    self._max_grad_norm,
                )
                self._optimizer.step()

            if self._target_kl is not None and float(old_approx_kl) > float(self._target_kl):
                break

        explained_var_info = self.calculate_explained_variance(b_batch)

        info = collections.OrderedDict()
        info["global_step"] = torch.tensor(self._global_step)
        info.update(p_info)
        info.update(q_info)
        info.update(explained_var_info)
        return info

    def _build_test_policies(self) -> None:
        self._test_policies["main"] = self._p_fn

    def _prepare_for_train(self, _train_steps: int, env_seed: int) -> int:
        self._total_timesteps = _train_steps
        self._num_iterations = self._total_timesteps // self._batch_size
        self._total_iterations = self._num_iterations
        self._current_iteration = 0

        obs0 = self._env_reset(seed=env_seed)
        self._next_obs = torch.as_tensor(obs0, device=self._device, dtype=torch.float32)
        self._next_dones = torch.zeros((self._num_envs,), device=self._device, dtype=torch.float32)
        self._current_state = obs0

        return self._num_iterations

    def get_advantage(self, batch: Dict) -> Tuple[Tensor, Tensor]:
        with torch.no_grad():
            next_values = self._q_fns[0](self._next_obs).reshape(1, -1)
            advantages = torch.zeros_like(batch["reward"], device=self._device)
            lastgaelam = 0
            for t in reversed(range(self._num_steps)):
                if t == self._num_steps - 1:
                    nextnonterminal = 1.0 - self._next_dones
                    nextvalues = next_values
                else:
                    nextnonterminal = 1.0 - batch["done"][t + 1]
                    nextvalues = batch["value"][t + 1]
                delta = batch["reward"][t] + self._discount * nextvalues * nextnonterminal - batch["value"][t]
                advantages[t] = lastgaelam = delta + self._discount * self._gae_lambda * nextnonterminal * lastgaelam
            returns = advantages + batch["value"]
        return advantages, returns

    def calculate_kl(self, logratio: Tensor):
        ratio = logratio.exp()
        with torch.no_grad():
            old_approx_kl = (-logratio).mean()
            approx_kl = ((ratio - 1) - logratio).mean()
            clipfracs = [((ratio - 1.0).abs() > self._clip_coef).float().mean().item()]
        return old_approx_kl, approx_kl, clipfracs

    def calculate_explained_variance(self, batch: Dict) -> Dict:
        y_pred = batch["value"].detach().cpu().numpy()
        y_true = batch["return"].detach().cpu().numpy()
        var_y = np.var(y_true)
        explained_var = np.nan if var_y == 0 else 1.0 - np.var(y_true - y_pred) / var_y
        return collections.OrderedDict(explained_variance=explained_var)

    def get_training_batch(self, batch: Dict) -> Dict:
        obs = batch["s1"].reshape((-1,) + self._observation_space.shape)
        logprobs = batch["logprob"].reshape(-1)
        actions = batch["a1"].reshape((-1,) + self._action_space.shape)
        advantages, returns = self.get_advantage(batch)
        advantages = advantages.reshape(-1)
        returns = returns.reshape(-1)
        values = batch["value"].reshape(-1)
        return collections.OrderedDict([
            ("s1", obs),
            ("a1", actions),
            ("logprob", logprobs),
            ("advantage", advantages),
            ("return", returns),
            ("value", values),
        ])

    def save(self, ckpt_name: str) -> None:
        pass

    def restore(self, ckpt_name: str) -> None:
        pass


class AgentModule(BaseAgentModule):
    def _build_modules(self) -> None:
        device = self._net_modules.device
        self._q_nets = nn.ModuleList()
        for _ in range(self._net_modules.n_q_fns):
            self._q_nets.append(self._net_modules.q_net_factory().to(device))
        self._p_net = self._net_modules.p_net_factory().to(device)
        self._q_target_nets = copy.deepcopy(self._q_nets)
        self._p_target_net = copy.deepcopy(self._p_net)

    @property
    def q_nets(self) -> nn.ModuleList:
        return self._q_nets

    @property
    def q_target_nets(self) -> nn.ModuleList:
        return self._q_target_nets

    @property
    def p_net(self) -> nn.Module:
        return self._p_net

    @property
    def p_target_net(self) -> nn.Module:
        return self._p_target_net